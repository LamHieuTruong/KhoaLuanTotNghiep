export const NOFICATION = "NOFICATION";
export const CLOSE_NOFICATION = "CLOSE_NOFICATION";
export const LOGIN = "LOGIN";

export const GET_LIST_USER = "GET_LIST_USER";
export const GET_DETAIL_USER = "GET_DETAIL_USER";
export const SET_USER = "SET_USER";
