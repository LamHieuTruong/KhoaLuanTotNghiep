export const SET_MODAL = "SET_MODAL";
export const HIDE_MODAL = "HIDE_MODAL";
