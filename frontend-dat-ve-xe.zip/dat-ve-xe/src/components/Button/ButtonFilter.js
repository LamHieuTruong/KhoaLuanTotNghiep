import React from "react";
import {Card, Button, Checkbox, Slider, Input, Rate} from "antd";

export default function ButtonFilter() {
	return <Button />;
}
